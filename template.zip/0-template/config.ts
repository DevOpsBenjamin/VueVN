import type { GameConfig } from '@generate/types'

function getConfig(): GameConfig
{
    return {
        name: "TemplateName",
    }
}

export default getConfig;