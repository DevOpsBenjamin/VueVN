import type { Mother_NPC } from "@/generate/types";

const mother: Mother_NPC = {
  name: "Jenna",
  flags: {},
  relation: 0,
  trust: 0
};

export default mother;