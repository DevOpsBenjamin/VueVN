// Sample project specific Player extension
export interface Player {
  name: string;
  personality?: string;
}